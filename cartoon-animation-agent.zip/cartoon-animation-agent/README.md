# Cartoon Animation Agent — free prototype

## Run it
This is a browser-based prototype. It loads Three.js from jsDelivr, so an internet connection is required.

### Easiest hosting route
1. Create a free GitHub account if you do not already have one.
2. Create a new public repository named `cartoon-animation-agent`.
3. Upload `index.html` from this folder.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
6. Open the Pages URL GitHub gives you on your Android phone.

The app itself has no paid API and no credit meter. Hosting on GitHub Pages is free for a public repository.

## Current limitations
This first version is a procedural 3D animation prototype, not a trained generative AI model. It interprets a few action words (walk, run, jump, sit, look), creates random cartoon people and a simple outdoor environment, and records the browser preview to WebM where supported. It does not yet generate arbitrary detailed assets or understand every sentence.
